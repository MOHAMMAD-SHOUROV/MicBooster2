package com.example.micbooster

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private var running = false
    private var gain = 1.0f // 100% (1.0) থেকে 500% (5.0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startBtn = findViewById<Button>(R.id.startBtn)
        val stopBtn = findViewById<Button>(R.id.stopBtn)
        val seek = findViewById<SeekBar>(R.id.seekGain)
        val gainTxt = findViewById<TextView>(R.id.gainText)

        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { _: Boolean -> }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        seek.max = 400
        seek.progress = 0
        gainTxt.text = "Gain: 100%"

        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                gain = 1.0f + progress / 100.0f
                val p = (gain * 100).toInt()
                gainTxt.text = "Gain: $p %"
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        startBtn.setOnClickListener {
            if (!running) startLoop()
        }
        stopBtn.setOnClickListener {
            running = false
        }
    }

    private fun startLoop() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            return
        }

        running = true

        thread {
            try {
                val sampleRate = 16000
                val audioFormat = AudioFormat.ENCODING_PCM_16BIT
                val channelIn = AudioFormat.CHANNEL_IN_MONO
                val channelOut = AudioFormat.CHANNEL_OUT_MONO

                val minRecBuf = AudioRecord.getMinBufferSize(sampleRate, channelIn, audioFormat)
                val minPlayBuf = AudioTrack.getMinBufferSize(sampleRate, channelOut, audioFormat)

                val recBufSize = max(minRecBuf, sampleRate/4)
                val playBufSize = max(minPlayBuf, sampleRate/4)

                val recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelIn,
                    audioFormat,
                    recBufSize
                )

                val track = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(audioFormat)
                                .setSampleRate(sampleRate)
                                .setChannelMask(channelOut)
                                .build()
                        )
                        .setBufferSizeInBytes(playBufSize)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                } else {
                    AudioTrack(
                        AudioManager.STREAM_VOICE_CALL,
                        sampleRate,
                        channelOut,
                        audioFormat,
                        playBufSize,
                        AudioTrack.MODE_STREAM
                    )
                }

                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.isSpeakerphoneOn = true

                val buf = ShortArray(1024)
                recorder.startRecording()
                track.play()

                while (running) {
                    val read = recorder.read(buf, 0, buf.size)
                    if (read > 0) {
                        for (i in 0 until read) {
                            var s = (buf[i] * gain).toInt()
                            s = min(Short.MAX_VALUE.toInt(), max(Short.MIN_VALUE.toInt(), s))
                            buf[i] = s.toShort()
                        }
                        track.write(buf, 0, read)
                    }
                }

                recorder.stop(); recorder.release()
                track.stop(); track.release()
                am.mode = AudioManager.MODE_NORMAL
                am.isSpeakerphoneOn = false

            } catch (e: Exception) {
                e.printStackTrace()
                running = false
            }
        }
    }
}
